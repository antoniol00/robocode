package prueba;

@SuppressWarnings("serial")
public class RobocodeException extends RuntimeException {

	public RobocodeException() {
		super();
	}

	public RobocodeException(String msg) {
		super(msg);

	}
}
